package com.example.sanae_belfrouh_projet;

import android.Manifest;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.UUID;

public class EditProfileActivity extends AppCompatActivity {


    private static final String TAG = "EditProfileActivity";
    RadioGroup sexe;
    RadioButton rdM, rdF;
    private Button saveProfile;
    private EditText fnameTxt, lnameTxt,filiereTxt, phoneTxt,emailTxt;
    private ImageView imageProfile;
    private FirebaseAuth auth;
    private FirebaseFirestore fstore;
    private DocumentSnapshot docuser;

    private String randomKey;
    private static final int CAMERA_REQUEST_CODE = 100;
    private static final int STORAGE_REQUEST_CODE = 101;
    private String[] cameraPermissions = new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private String[] storagePermissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};;
    private static final int IMAGE_PICK_CAMERA_CODE = 102;
    private static final int IMAGE_PICK_GALLERY_CODE = 103;

    private Button btnChangePhoto;
    private Uri imageUri, imageOldUri;

    private FirebaseStorage storage;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        auth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();

        saveProfile = findViewById(R.id.idBtnSave);
        fnameTxt = findViewById(R.id.idRegisterfname);
        filiereTxt = findViewById(R.id.idRegisterfiliere);
        lnameTxt = findViewById(R.id.idRegisterlname);
        phoneTxt = findViewById(R.id.idRegisterPhone);
        emailTxt = findViewById(R.id.idRegisterEmail);
        emailTxt.setEnabled(false);
        sexe =(RadioGroup) findViewById(R.id.radioGroup2);
        rdM = (RadioButton) findViewById(R.id.radioButton2);
        rdF = (RadioButton) findViewById(R.id.radioButton3);
        imageProfile = findViewById(R.id.imageProfile);
        btnChangePhoto = findViewById(R.id.idBtnChangePhoto);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        // save image
        imageProfile.setOnClickListener(e->{
            optionChooseImage();
        });
        btnChangePhoto.setOnClickListener(e->{
            optionChooseImage();
        });
        //Save change profile
        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selected = sexe.getCheckedRadioButtonId();
                RadioButton gender= findViewById(selected);

                DocumentReference docref = fstore.collection("freelancers").document(auth.getCurrentUser().getUid());
                HashMap<String,Object> user = new HashMap<>();
                user.put("firstname", fnameTxt.getText().toString());
                user.put("lastname", lnameTxt.getText().toString());
                user.put("Filiere",filiereTxt.getText().toString());
                user.put("email", auth.getCurrentUser().getEmail());
                user.put("profile", String.valueOf(imageUri));
                user.put("phone", phoneTxt.getText().toString());
                String sexeUser = gender.getText().toString();
                user.put("sexe", gender.getText().toString());
                docref.update(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(EditProfileActivity.this, "Profile updated", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(EditProfileActivity.this, LocationActivity.class));
                        }
                    }
                });
            }
        });
    }


    private void optionChooseImage(){
        String[] options = {"Camera","Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Image From");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(i == 0){
                    if(!checkCameraPermission()){
                        requestCameraPermission();
                    }else {
                        pickFromCamera();
                    }
                }else if(i == 1) {
                    if(!checkStoragePermission()){
                        requestStoragePermission();
                    }else {
                        choosePicture();
                    }
                }
            }
        });
        builder.create().show();
    }
    // Photo from camera
    private void pickFromCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Image title");
        values.put(MediaStore.Images.Media.DESCRIPTION, "Image description");
        Log.d("test","here");
        this.imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Log.d("test",imageUri.toString());
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,this.imageUri);
        startActivityForResult(cameraIntent, IMAGE_PICK_CAMERA_CODE);
        Toast.makeText(this, "Camera & Storage permissions are required", Toast.LENGTH_SHORT).show();
    }
    // Chose image from gallery
    private void choosePicture() {
        Intent intent = new Intent();
        intent.setType("image/**");
        intent.setAction(intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }
    private boolean checkStoragePermission(){
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result;
    }
    private void requestStoragePermission(){
        ActivityCompat.requestPermissions(this,storagePermissions,STORAGE_REQUEST_CODE);
    }

    private boolean checkCameraPermission(){
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) == (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }
    private void requestCameraPermission(){
        ActivityCompat.requestPermissions(this,cameraPermissions,CAMERA_REQUEST_CODE);
    }
    //Choose and save profile image
    @Override
    protected void onActivityResult(int reqCode, int resCode, @Nullable Intent data){
        super.onActivityResult(reqCode, resCode, data);
        if(resCode==RESULT_OK) {
            if (reqCode == IMAGE_PICK_GALLERY_CODE && data != null && data.getData() != null) {
                imageUri = data.getData();
                imageProfile.setImageURI(imageUri);
                uploadPicture();

            } else if (reqCode == IMAGE_PICK_CAMERA_CODE) {
                // Récupérer le chemin de l'image temporaire
                imageProfile.setImageURI(imageUri);
                uploadPicture();
            }
        }
    }


    private void uploadPicture() {
        randomKey = UUID.randomUUID().toString();
        StorageReference riversRef = storageReference.child("images/" + randomKey);
        riversRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(EditProfileActivity.this, "Image uploaded!", Toast.LENGTH_LONG).show();
                // Code to update the profile image
                riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        String imageUrl = uri.toString();
                        Picasso.get().load(imageUrl).into(imageProfile);
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(EditProfileActivity.this, "Failed To Upload!", Toast.LENGTH_LONG).show();
            }
        });
    }

   /* @Override
    protected void onActivityResult(int reqCode, int resCode, @Nullable Intent data){
        super.onActivityResult(reqCode, resCode, data);
        if(reqCode==1 && resCode==RESULT_OK &&  data!=null && data.getData()!=null){
            imageUri=data.getData();
            imageProfile.setImageURI(imageUri);
            //uploadPicture();
        }
    }*/

    //Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    //clicked menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch ((item.getItemId())){
            case R.id.idMaps:
                startActivity(new Intent(EditProfileActivity.this, LocationActivity.class));
                return true;
            case R.id.idAction:
                startActivity(new Intent(EditProfileActivity.this, ActionActivity.class));
                return true;
            case R.id.idLogout:
                startActivity(new Intent(EditProfileActivity.this, MainActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(auth.getCurrentUser() != null) {

            DocumentReference docref = fstore.collection("freelancers").document(auth.getCurrentUser().getUid());
            docref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot doc = task.getResult();

                        if(doc.exists()){
                            phoneTxt.setText(doc.get("phone").toString());
                            emailTxt.setText(doc.get("email").toString());
                            fnameTxt.setText(doc.get("firstname").toString());
                            lnameTxt.setText(doc.get("lastname").toString());
                            filiereTxt.setText(doc.get("filiere").toString());

                            if(doc.get("sexe").equals("Male"))
                                rdM.setChecked(true);
                            else
                                rdF.setChecked(true);
                            imageProfile.setImageURI(Uri.parse(doc.get("profile").toString()));
                        }else{
                            Toast.makeText(EditProfileActivity.this, "USer nulll", Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "no data");
                        }
                    }
                }
            });

        }else {
            docuser = null;
        }
    }
}