package com.example.sanae_belfrouh_projet;
import android.app.IntentService;
import android.content.Intent;
import androidx.annotation.NonNull;
import com.google.android.gms.location.ActivityRecognitionResult;
import com.google.android.gms.location.DetectedActivity;

public class ActivityRecognizedService extends IntentService {

    public ActivityRecognizedService() {
        super("ActivityRecognizedService");
    }

    @Override
    protected void onHandleIntent(@NonNull Intent intent) {
        if (ActivityRecognitionResult.hasResult(intent)) {
            ActivityRecognitionResult result = ActivityRecognitionResult.extractResult(intent);
            DetectedActivity mostProbableActivity = result.getMostProbableActivity();

            // Vous pouvez utiliser mostProbableActivity pour déterminer l'activité de l'utilisateur
            // et effectuer les actions appropriées.
        }
    }
}
