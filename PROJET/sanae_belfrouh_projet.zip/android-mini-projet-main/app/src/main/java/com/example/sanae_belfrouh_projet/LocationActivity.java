/*
package com.example.sanae_belfrouh_projet;

import android.Manifest;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.sanae_belfrouh_projet.db.MyDataBase;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.ActivityRecognition;
import com.google.android.gms.location.ActivityRecognitionClient;
import com.google.android.gms.location.ActivityTransition;
import com.google.android.gms.location.ActivityTransitionEvent;
import com.google.android.gms.location.ActivityTransitionRequest;
import com.google.android.gms.location.ActivityTransitionResult;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

public class LocationActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int REQUEST_CODE = 1000;
    SupportMapFragment supportMapFragment;
    FusedLocationProviderClient client;
    double longitude, latitude, speed;
    private static TextView action;
    private String email;
    MyDataBase mydb = new MyDataBase(LocationActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        if (!checkGooglePlayServicesAvailability()) {
            return;
        }
        email = "sanaebelfrouh@gmail.com";

        action = findViewById(R.id.action);

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
        supportMapFragment.getMapAsync(this);

        client = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(LocationActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(LocationActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }

        requestActivityUpdates();
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        client.getLastLocation().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Location location = task.getResult();
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    supportMapFragment.getMapAsync(LocationActivity.this);
                }
            }
        });
    }

    private void requestActivityUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQUEST_CODE);
            return;
        }

        ActivityRecognitionClient activityRecognitionClient = ActivityRecognition.getClient(this);

        List<ActivityTransition> transitions = new ArrayList<>();

        for (int activityType : new int[]{DetectedActivity.WALKING, DetectedActivity.RUNNING, DetectedActivity.STILL, DetectedActivity.ON_FOOT}) {
            transitions.add(new ActivityTransition.Builder()
                    .setActivityType(activityType)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
                    .build());

            transitions.add(new ActivityTransition.Builder()
                    .setActivityType(activityType)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_EXIT)
                    .build());
        }

        ActivityTransitionRequest request = new ActivityTransitionRequest(transitions);

        activityRecognitionClient.requestActivityTransitionUpdates(request, getPendingIntent())
                .addOnSuccessListener(aVoid -> {
                    // Transitions were successfully registered.
                })
                .addOnFailureListener(e -> {
                    // Transitions could not be registered.
                });
    }

    private PendingIntent getPendingIntent() {
        Intent intent = new Intent("com.example.sanae_belfrouh_projet.ACTION_PROCESS_ACTIVITY_TRANSITIONS");
        return PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }
    private boolean checkGooglePlayServicesAvailability() {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this);

        if (resultCode != ConnectionResult.SUCCESS) {
            if (googleApiAvailability.isUserResolvableError(resultCode)) {
                googleApiAvailability.getErrorDialog(this, resultCode, 2404).show();
            } else {
                Toast.makeText(this, "Cet appareil n'est pas compatible avec les services Google Play.", Toast.LENGTH_LONG).show();
                finish();
            }
            return false;
        }
        return true;}

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(latitude, longitude);
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
        googleMap.addMarker(markerOptions);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        } else if (requestCode == REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestActivityUpdates();
            }
        }
    }

    public static class ActivityTransitionBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (ActivityTransitionResult.hasResult(intent)) {
                ActivityTransitionResult result = ActivityTransitionResult.extractResult(intent);
                for (ActivityTransitionEvent event : result.getTransitionEvents()) {
                    String activityType = getActivityString(event.getActivityType());
                    String transitionType = event.getTransitionType() == ActivityTransition.ACTIVITY_TRANSITION_ENTER ? "ENTER" : "EXIT";
                    action.setText("Activity: " + activityType + "\nTransition: " + transitionType);
                }
            }
        }

        private String getActivityString(int activityType) {
            switch (activityType) {
                case DetectedActivity.WALKING:
                    return "Walking";
                case DetectedActivity.RUNNING:
                    return "Running";
                case DetectedActivity.STILL:
                    return "Still";
                case DetectedActivity.ON_FOOT:
                    return "On Foot";
                default:
                    return "Unknown";
            }
        }
    }
}
*/



package com.example.sanae_belfrouh_projet;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;

import com.example.sanae_belfrouh_projet.db.MyDataBase;
import com.example.sanae_belfrouh_projet.model.Activity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class LocationActivity extends AppCompatActivity implements SensorEventListener {



    SupportMapFragment supportMapFragment;
    FusedLocationProviderClient client;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    double longitude,latitude,speed;
    private TextView action;
    private String email;
    private long lastUpdate = 0;
    private float last_x, last_y, last_z;
    MyDataBase mydb = new MyDataBase(LocationActivity.this);

    double magnitudeP = 0, mPrevious=0;
    double magnitudeD, mDelta;
    float x, y, z;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        email="belfrouhsanae@gmail.com";

/**************** Activity *****/

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        action = (TextView) findViewById(R.id.idTextActivity);



/**************** Get location in maps *****/

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.google_map);

        client = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(LocationActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(LocationActivity.this
                    , new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }
    }

    //Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    //clicked menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch ((item.getItemId())){
            case R.id.idEditProfile:
                startActivity(new Intent(LocationActivity.this, EditProfileActivity.class));
                return true;
            case R.id.idAction:
                startActivity(new Intent(LocationActivity.this, ActionActivity.class));
                return true;
            case R.id.idLogout:
                startActivity(new Intent(LocationActivity.this, MainActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //Get current location
    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(final Location location) {
                if(location != null){
                    supportMapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                            LatLng latLng = new LatLng(latitude, longitude);
                            MarkerOptions options = new MarkerOptions().position(latLng).title("I am there");
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));
                            googleMap.addMarker(options);
                        }
                    });
                }
            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        }
    }

    //Get actions
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            getAccelerometer(sensorEvent);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener((SensorEventListener) this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                sensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void getAccelerometer(SensorEvent event){
        float[] values = event.values;
        x = values[0];
        y = values[1];
        z = values[2];

        //
        long curTime = System.currentTimeMillis();

        if ((curTime - lastUpdate) > 100) {
            long diffTime = (curTime - lastUpdate);
            lastUpdate = curTime;
            speed = Math.abs(x + y + z - last_x - last_y - last_z)/ diffTime * 10000;
            last_x = x;
            last_y = y;
            last_z = z;
        }
        int count = 0;
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(this);
        // activité : Sauter
        double d = Math.round(Math.sqrt(Math.pow(2, x) + Math.pow(2, y) + Math.pow(2, z)) - 2);
        float threshold_sauter =preferences.getFloat("sauter", 10);
        // activité : Marcher
        double Magnitude = Math.sqrt(Math.pow(2, x) + Math.pow(2, y) + Math.pow(2, z));
        magnitudeD = Magnitude - magnitudeP;
        magnitudeP = Magnitude;
        float threshold_marcher =preferences.getFloat("marcher", 5);
        // activité : Assis
        double m = Math.sqrt(Math.pow(2, x) + Math.pow(2, y) + Math.pow(2, z));
        mDelta = m - mPrevious;
        mPrevious = m;
        float threshold_assis =preferences.getFloat("assis", 1);

        if(d != 0 && d<=threshold_sauter){
            count=1;
        }else if(magnitudeD > threshold_marcher){
            count=2;
        }else if(mDelta > threshold_assis){
            count=3;
        }
        String detail;
        if (count == 1){
            detail = "Latitude : "+latitude+"\nLongitude : "
                    +longitude+"\nSpeed [m/s] : "+speed;
            action.setText("Activity : Jumped\n"+ detail);
            mydb.addActivity(new Activity(email, "Jumped", latitude, longitude, speed));
            action.invalidate();
        }else if (count == 2){
            detail = "Latitude : "+latitude+"\nLongitude : "
                    +longitude+"\nSpeed [m/s] : "+speed;
            // action.setText("Activity : Running\n"+detail);
            mydb.addActivity(new Activity(email, "Running", latitude, longitude, speed));
            // action.invalidate();
            System.out.printf("Running");
        }else if(count == 3){
            detail = "Latitude : "+latitude+"\nLongitude : "
                    +longitude+"\nSpeed [m/s] : "+0;
            mydb.addActivity(new Activity(email, "Sitting", latitude, longitude, 0));
            action.setText("Activity : Sitting\n"+detail);
            action.invalidate();
        }else if(count == 0 && z<4){
            detail = "Latitude : "+latitude+"\nLongitude : "
                    +longitude+"\nSpeed [m/s] : "+speed;
            mydb.addActivity(new Activity(email, "Sitting", latitude, longitude, speed));
            action.setText("Activity : Standing\n"+detail);
            action.invalidate();
        }

    }
}


